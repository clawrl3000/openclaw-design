---
name: seo-signals
description: >
  Comprehensive SEO analysis grounded in Google's actual ranking signals from the
  2024 Content Warehouse API leak (2,596 modules, 14,014 attributes) combined with
  practical audit workflows. Covers technical SEO, on-page optimization, Core Web
  Vitals (INP), E-E-A-T (Dec 2025 update), schema markup, NavBoost click signals,
  site authority, content quality scoring, link evaluation, AI search / GEO
  optimization, programmatic SEO, and strategic planning. Integrates with Ahrefs
  MCP. Triggers on: "SEO", "audit", "ranking signals", "NavBoost", "site authority",
  "schema", "Core Web Vitals", "E-E-A-T", "AI Overviews", "GEO", "technical SEO",
  "content quality", "structured data", "Google leak", "how Google ranks pages".
---

# SEO Signals — Leak-Grounded SEO Analysis

Comprehensive SEO analysis that combines practical audit workflows with deep
knowledge of Google's internal ranking systems from the 2024 Content Warehouse
API leak.

## What Makes This Different

Traditional SEO skills rely on Google's public documentation. This skill is
grounded in what Google actually does — confirmed by the 2024 leak of 2,596
modules and 14,014 attributes from Google's Content Warehouse API.

| Google's Public Claim | What the Leak Revealed |
|---|---|
| "We don't use domain authority" | `siteAuthority` attribute exists and is used |
| "Chrome data isn't used for ranking" | NavBoost ingests Chrome click data extensively |
| "Click data is too noisy to use" | NavBoost is one of the most powerful re-ranking signals |
| "We don't sandbox new sites" | `hostAge` attribute confirms new-domain sandboxing |
| "PageRank is outdated" | PageRank is still computed for every indexed document |

**Caveat:** The leak shows what attributes exist, not exact weights. Treat signals as confirmed factors but impact levels as informed estimates.

## Core Signal Categories

| Category | Key Signals | Impact | Reference |
|---|---|---|---|
| NavBoost (Clicks) | goodClicks, badClicks, lastLongestClicks, unicornClicks | Critical | `references/navboost-signals.md` |
| Site Authority | siteAuthority, nsr, pagerankNs, hostAge, chromeInTotal | Critical | `references/site-authority-signals.md` |
| Content Quality | contentEffort, chard, tofu, OriginalContentScore, bodyWordsToTokensRatio | High | `references/content-quality-signals.md` |
| Author & Entity | annotatedEntityId, authorObfuscatedGaiaStr, topicalityScore | High | `references/author-entity-signals.md` |
| Link Signals | penguinPenalty, uniqueDomainCount, pagerankWeight, freshAnchorCount | High | `references/link-signals.md` |
| Chrome & UX | chromeInTotal, directFrac, voterTokenCount | Medium | `references/chrome-ux-signals.md` |
| Special Treatments | pandaDemotion, scamness, unauthoritativeScore, productReview* | High | `references/special-treatments.md` |
| Ranking Architecture | Ascorer → NavBoost Twiddler → QualityBoost → Diversity | Context | `references/ranking-architecture.md` |

For attribute-level lookup, consult `references/signal-catalog.md` — alphabetical index of 150+ confirmed attributes.

## Workflows

### 1. Full Page Audit (Signal-Grounded)

1. **Fetch and analyze the page** — HTML, content, metadata, structure, title, headings, author, dates, word count, links
2. **Evaluate by signal category:**
   - **NavBoost readiness** — Is the title click-worthy? Does content satisfy intent (prevent badClicks)? Is it comprehensive enough to be the lastLongestClick?
   - **Content quality** — Token diversity (bodyWordsToTokensRatio), originality (OriginalContentScore), content effort, keyword stuffing detection
   - **Authority signals** — Domain age, brand recognition (chromeInTotal, directFrac), site quality consistency (siteQualityStddev)
   - **E-E-A-T** — Author byline, credentials, first-hand experience, trust signals. Load `references/eeat-framework.md`
   - **Technical SEO** — Crawlability, indexability, Core Web Vitals (INP, not FID), mobile-first, HTTPS. Load `references/cwv-thresholds.md`
   - **Schema markup** — JSON-LD detection, validation, generation. Load `references/schema-types.md`
   - **Link profile** — Domain diversity, quality tiers, anchor relevance, freshness
   - **AI search readiness** — GEO optimization, AI crawler access, llms.txt, citability. Load `references/geo-optimization.md`
3. **Score and prioritize** — SEO Health Score (0-100) with signal-grounded recommendations
4. **Deliver actionable report** — Cite specific leaked attributes to ground each recommendation

### 2. Content Optimization

1. Analyze content signals — token count, vocabulary diversity, title-query alignment (titlematchScore), freshness (bylineDate, lastSignificantUpdate)
2. Evaluate author/entity presence — byline, credentials, entity associations, brand mentions
3. Assess freshness — QDF triggers, publish dates, content update history
4. Optimize for engagement — improve elements that drive goodClicks and lastLongestClicks
5. Apply the checklist in `examples/content-optimization-checklist.md`

### 3. Competitor Signal Gap Analysis

1. Identify top competitors for target keywords
2. Compare signal strengths across categories (authority, content, links, engagement)
3. Flag categories where competitor is stronger
4. Prioritize gaps in high-impact categories (NavBoost, Content Quality, Links)
5. Use template in `examples/signal-gap-analysis.md`

### 4. Ranking Question Answers

When asked "how does Google rank X" or "does Google use Y":
1. Search `references/signal-catalog.md` for relevant attributes
2. Read the category reference file for deeper context
3. Cite specific attributes and modules from the leak
4. Note contradictions with Google's public statements

## Scoring Methodology

### SEO Health Score (0-100)

| Category | Weight | Key Leaked Signals |
|----------|--------|-------------------|
| Content Quality | 25% | contentEffort, OriginalContentScore, bodyWordsToTokensRatio, chard, vlq |
| Technical SEO | 20% | Crawlability, indexability, CWV (INP), mobile-first |
| Authority & Trust | 20% | siteAuthority, nsr, pagerankNs, chromeInTotal, directFrac |
| On-Page SEO | 15% | titlematchScore, heading structure, keyword placement |
| Link Profile | 10% | uniqueDomainCount, penguinPenalty, anchor quality |
| Schema / Structured Data | 5% | JSON-LD presence, validation, type coverage |
| AI Search Readiness | 5% | Citability, AI crawler access, llms.txt |

### Priority Levels
- **Critical**: Blocks indexing, triggers demotions (pandaDemotion, scamness), or causes penalties
- **High**: Directly impacts ranking signals (weak NavBoost, low contentEffort, unauthoritativeScore)
- **Medium**: Optimization opportunity (schema gaps, freshness signals, link diversity)
- **Low**: Nice to have (minor technical issues, cosmetic improvements)

## Quality Gates

Hard rules — load `references/quality-gates.md` for full thresholds:
- ⚠️ WARNING at 30+ location pages (enforce 60%+ unique content)
- 🛑 HARD STOP at 50+ location pages (require user justification)
- Never recommend HowTo schema (deprecated Sept 2023)
- FAQ schema only for government and healthcare sites
- All CWV references use INP, never FID
- Content must pass thin content thresholds per page type

## Reference Files

Load on-demand as needed — do NOT load all at startup:

### Leaked Signal Intelligence
- `references/navboost-signals.md` — Click data, pogo-sticking, 13-month window, Chrome integration
- `references/site-authority-signals.md` — Domain trust, age, sandbox, PageRank variants
- `references/content-quality-signals.md` — Freshness, tokens, title matching, version history, CHARD/KETO/TOFU
- `references/author-entity-signals.md` — E-E-A-T signals, author scoring, entity recognition
- `references/link-signals.md` — Backlink quality tiers, diversity, freshness, anchor text, Penguin
- `references/chrome-ux-signals.md` — Engagement metrics, session data, Chrome browser data
- `references/special-treatments.md` — Demotions, whitelists, YMYL treatments, product reviews
- `references/ranking-architecture.md` — CompositeDoc, Ascorer, Twiddlers, CompressedQualitySignals
- `references/signal-catalog.md` — Alphabetical index of 150+ confirmed attributes

### Practical SEO References
- `references/eeat-framework.md` — E-E-A-T evaluation criteria (Sept 2025 QRG + Dec 2025 core update)
- `references/cwv-thresholds.md` — Core Web Vitals thresholds, LCP subparts, measurement tools
- `references/schema-types.md` — All supported schema types with deprecation status (Feb 2026)
- `references/quality-gates.md` — Content length minimums, uniqueness thresholds, title/meta rules
- `references/geo-optimization.md` — AI Overviews, ChatGPT, Perplexity, GEO analysis criteria
- `references/google-seo-reference.md` — Quick reference for Google Search essentials

### Workflow Guides (from claude-seo sub-skills)
- `references/workflows/audit.md` — Full website audit with parallel subagent delegation
- `references/workflows/page.md` — Deep single-page analysis
- `references/workflows/technical.md` — Technical SEO audit (8 categories)
- `references/workflows/content.md` — E-E-A-T and content quality analysis
- `references/workflows/schema.md` — Schema markup detection, validation, generation
- `references/workflows/images.md` — Image optimization (alt text, formats, lazy loading, CLS)
- `references/workflows/sitemap.md` — Sitemap analysis and generation
- `references/workflows/hreflang.md` — Hreflang/i18n audit and generation
- `references/workflows/programmatic.md` — Programmatic SEO at scale with quality gates
- `references/workflows/competitor-pages.md` — "X vs Y" and alternatives page generation
- `references/workflows/plan.md` — Strategic SEO planning process

### Industry Plan Templates
- `references/plan-templates/saas.md` — SaaS SEO strategy
- `references/plan-templates/ecommerce.md` — E-commerce SEO strategy
- `references/plan-templates/local-service.md` — Local service business SEO
- `references/plan-templates/publisher.md` — Publisher/media SEO strategy
- `references/plan-templates/agency.md` — Agency SEO strategy
- `references/plan-templates/generic.md` — General-purpose SEO strategy

### Templates & Checklists
- `references/on-page-checklist.md` — Pre-publish on-page SEO checklist
- `references/content-brief-template.md` — Content brief creation template
- `references/schema-templates.json` — Ready-to-paste JSON-LD templates (VideoObject, BroadcastEvent, Clip, SeekToAction, SoftwareSourceCode)

### Examples
- `examples/page-audit-workflow.md` — Complete signal-grounded audit walkthrough
- `examples/content-optimization-checklist.md` — Signal-by-signal optimization checklist
- `examples/signal-gap-analysis.md` — Competitive signal comparison framework

### Scripts (Python, for Claude Code)
- `scripts/fetch_page.py` — Fetch and return page HTML
- `scripts/parse_html.py` — Parse HTML for SEO elements
- `scripts/capture_screenshot.py` — Take page screenshots (requires Playwright)
- `scripts/analyze_visual.py` — Visual layout analysis

### Subagents (for Claude Code parallel audits)
- `agents/seo-technical.md` — Crawlability, indexability, security, CWV
- `agents/seo-content.md` — E-E-A-T, readability, thin content
- `agents/seo-schema.md` — Detection, validation, generation
- `agents/seo-sitemap.md` — Structure, coverage, quality gates
- `agents/seo-performance.md` — Core Web Vitals measurement
- `agents/seo-visual.md` — Screenshots, mobile testing, above-fold

## Ahrefs MCP Integration

When Ahrefs MCP tools are available, use them to enrich signal analysis:

| Task | Tool | Enhances Signal Category |
|------|------|------------------------|
| Keyword metrics | `keywords-explorer-overview` | Content targeting |
| Keyword ideas | `keywords-explorer-matching-terms` | Content strategy |
| Site metrics | `site-explorer-metrics` | Site Authority |
| Organic keywords | `site-explorer-organic-keywords` | Competitor gaps |
| Top pages | `site-explorer-top-pages` | Content Quality |
| Backlinks | `site-explorer-all-backlinks` | Link Signals |
| Referring domains | `site-explorer-refdomains` | uniqueDomainCount |
| Competitors | `site-explorer-organic-competitors` | Gap analysis |
| Site audit | `site-audit-issues` | Technical SEO |
| SERP analysis | `serp-overview-serp-overview` | NavBoost context |

Always check `ahrefs:doc` for current parameter requirements before calling.

## Principles

- **Signals over speculation** — Ground every recommendation in confirmed leaked attributes
- **Intent first** — Match content to what searchers want (prevents badClicks)
- **Authority is earned** — siteAuthority, chromeInTotal, and directFrac reflect real brand strength
- **Consistency matters** — siteQualityStddev penalizes sites with uneven quality
- **Click performance is king** — NavBoost (lastLongestClicks) can override traditional SEO signals
- **Technical before content** — Fix crawl issues before chasing new pages
- **Quality > quantity** — 10 great pages beat 100 thin ones (pandaDemotion is site-level)
- **AI search is different** — Brand mentions correlate 3× more with AI citations than backlinks
