# On-Page SEO Checklist

Run before publishing any page targeting organic traffic.

## Title Tag
- [ ] Primary keyword included (front-loaded when natural)
- [ ] Under 60 characters (55 ideal)
- [ ] Compelling/clickable (not just keyword stuffed)
- [ ] Unique across site

## Meta Description
- [ ] Primary keyword included
- [ ] 150-160 characters
- [ ] Includes hook or value prop
- [ ] Has implicit or explicit CTA
- [ ] Unique across site

## URL
- [ ] Primary keyword in URL
- [ ] Short and clean (3-5 words max)
- [ ] Hyphens between words
- [ ] No parameters, numbers, or dates (unless necessary)

## Headers
- [ ] Single H1 with primary keyword
- [ ] H2s for main sections (keywords where natural)
- [ ] Proper hierarchy (H1 → H2 → H3)
- [ ] No skipped levels

## Content
- [ ] Primary keyword in first 100 words
- [ ] Secondary keywords distributed naturally
- [ ] Matches search intent (check SERP)
- [ ] Answers the query directly (no fluff intros)
- [ ] Readable: short paragraphs, subheads, bullets where needed
- [ ] Word count competitive with ranking pages

## Internal Links
- [ ] 3-5+ internal links to related pages
- [ ] Descriptive anchor text (not "click here")
- [ ] Links TO this page from relevant existing content
- [ ] Logical site structure (hub → spoke)

## Images
- [ ] Alt text on all images
- [ ] Primary keyword in main image alt (if natural)
- [ ] Compressed file sizes
- [ ] Descriptive file names (not IMG_001.jpg)

## Technical
- [ ] Page is indexable (no noindex, not blocked by robots.txt)
- [ ] Canonical tag points to self (or correct canonical)
- [ ] Mobile-friendly
- [ ] Loads fast (<3s)
- [ ] No broken links

## Schema (if applicable)
- [ ] Article schema for blog posts
- [ ] Product schema for product pages
- [ ] LocalBusiness for location pages
- [ ] FAQ schema if FAQ section exists
- [ ] Validated in Schema Markup Validator

## Final Check
- [ ] Read the page as a user — does it answer the query?
- [ ] Compare to top 3 ranking pages — is yours better?
- [ ] Clear CTA present
