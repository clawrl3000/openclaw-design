# Content Brief Template

Use this structure when creating briefs for new content.

---

## [Page Title]

### Target Keywords

| Keyword | Volume | KD | Intent |
|---------|--------|-----|--------|
| **Primary:** [keyword] | [vol] | [kd] | [intent] |
| Secondary: [keyword] | [vol] | [kd] | [intent] |
| Secondary: [keyword] | [vol] | [kd] | [intent] |

### Search Intent

**Type:** [Informational / Transactional / Navigational / Commercial Investigation]

**What the searcher wants:**
[1-2 sentences describing what someone searching this keyword is trying to accomplish]

### Content Specs

- **Target word count:** [X] words (based on top 3 ranking pages averaging [Y])
- **Content type:** [Blog post / Landing page / Product page / Guide / etc.]
- **Tone:** [Educational / Persuasive / Technical / Casual / etc.]

### Required Sections

1. **[H2: Section name]**
   - Cover: [what to include]
   - Keywords to work in: [secondary keywords]

2. **[H2: Section name]**
   - Cover: [what to include]
   - Keywords to work in: [secondary keywords]

3. **[H2: Section name]**
   - Cover: [what to include]

[Add more sections as needed based on SERP analysis]

### Questions to Answer

Based on "People Also Ask" and related searches:
- [Question 1]
- [Question 2]
- [Question 3]

### Internal Links

**Link TO these pages:**
- [Page title] — anchor text suggestion: [text]
- [Page title] — anchor text suggestion: [text]

**Request links FROM these existing pages:**
- [Existing page URL]
- [Existing page URL]

### Competitor Reference

**Top 3 ranking pages to beat:**
1. [URL] — Strengths: [X] / Gaps: [Y]
2. [URL] — Strengths: [X] / Gaps: [Y]
3. [URL] — Strengths: [X] / Gaps: [Y]

**How to beat them:**
[1-2 sentences on angle, depth, or format that will differentiate]

### CTA

**Primary action:** [What should the reader do?]
**CTA placement:** [End of post / Inline / Sidebar / etc.]

### Notes

[Any additional context, constraints, or considerations]

---

## Brief Checklist

Before handing off:
- [ ] Primary keyword has realistic KD for site authority
- [ ] Intent matches content type
- [ ] Sections cover what top pages cover + more
- [ ] Internal link targets identified
- [ ] Differentiation angle is clear
